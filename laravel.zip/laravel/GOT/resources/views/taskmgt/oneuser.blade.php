<!--@extends('master')-->
@extends('layouts.mainlayout')
@section('content')
<body style="background-color: lightblue">

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 50px; float: left; text-align:center"><button onclick="location.href='{{route('alluser')}}'" class="btn btn-primary"><<</button></span></td>   
        </tr>
</table>
    <div style="background-color: white;width:60%; margin-left: 200px"><br>
        
    <h1 align='center'> USER DETAIL </h1><br>
    
    <table align='center' style="width:70%" class="table">
        @foreach($users as $user)
        <tr>
            <td><strong>Name</strong></td>
            <td>{{$user->name}}</td>
        </tr>
        <tr>
            <td><strong>Email</strong></td>
            <td>{{$user->email}}</td>
        </tr>
        <tr>
            <td><strong>Gender</strong></td>
            <td>{{$user->gender}}</td>
        </tr>
        <tr>
            <td><strong>Role</strong></td>
            <td>{{$user->role}}</td>
        </tr>
        <tr>
            <td><strong>Address</strong></td>
            <td>{{$user->address}}</td>
        </tr>
        <tr>
            <td><strong>Phone Number</strong></td>
            <td>{{$user->phoneno}}</td>
        </tr>
        <tr>
            <td><strong>Status</strong></td>
            <td>{{$user->status}}</td>
        </tr>
        
        
            @endforeach
    </table><br>
    </div>

</body>   
@endsection