<!--@extends('master')-->
@extends('layouts.mainlayout')

@section('content')

<body style="background-color: lightblue">

<h1 align='center'> TASK DETAIL </h1>

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 100px; float: left; text-align:center"><button onclick="location.href='{{route('admin.home')}}'" class="btn btn-primary"><<</button></span></td>
            <td><span class="right" style="width: 100px; float: right; text-align:center"><button onclick="location.href='{{route('task.add')}}'" class="btn btn-primary">+</button></span></td>
        </tr>
</table>

        @if(\Session::has('success'))
        <div class="alert alert-success">
            <p>{{\Session::get ('success')}}</p>
        </div>
        @else
        
        @endif
        
<div class="row">
    <div style="background-color: white;width: 80%; margin-left: 120px"><br><br><br>
    <table style="width:80%" class='table' align='center'>
    <tr>
        <td><strong>Task Name</strong></td>
        <td><strong>Task Description</strong></td>
        <td><strong>Task Assigner</strong></td>
        <td><strong>Task Developer</strong></td>
        <td><strong>Edit</strong></td>
        <td><strong>Delete</strong></td>
    </tr>
    @foreach($tasks as $task)
    <tr>
        <td>{{$task->taskname}}</td>
        <td>{{$task->description}}</td>
        <td>{{$task->assigner}}</td>
        <td>{{$task->developer}}</td>
        <td><span class="left" style="width: 60px; text-align:center"><button onclick="location.href='{{route('task.updateform',$task->id)}}'" class="btn btn-success">Edit</button></span>
        </td>
        <td><span class="left" style="width: 80px; text-align:center"><button onclick="location.href='{{route('task.taskdelete',$task->id)}}'" class="btn btn-success">Delete</button></span>
        </td>
    </tr>
    @endforeach
    </table><br>
    </div>
</div>
</body>
@endsection