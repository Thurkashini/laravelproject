<!--@extends('master')-->
@extends('layouts.mainlayout')

@section('content')
<body style="background-color: lightblue">
<table style="width:100%" class='table' align='center'>
        <tr>
            <td style="width:20px"><button onclick="location.href='{{route('task.detail')}}'" class="btn btn-primary"><<</button></td>
        </tr>
</table>

       
        @if(count ($errors)>0)
        <div class="alert alert-danger">
            <ul>
                @foreach($errors ->all () as $error)
                <li>
                    {{$error}}
                </li>
            </ul>
                @endforeach
        </div>
        @else
        
        @endif
        
        @if(\Session::has('success'))
        <div class="alert alert-success">
            <p>{{\Session::get ('success')}}</p>
        </div>
        @else
        
        @endif
        
        
        <div class="col-md-3"></div>
        <div class="jumbotron jumbotron-fluid" style="height: 430px; width: 800px; margin-left: 200px; background-color:white;">
                <br/>
                <h2 class="text-center"><strong>Create New Task</strong></h2>
           <br />
           <div class="col-md-6" style="align-content: center; padding-left: 70px" >  
               <form method="POST" style="width: 550px" action="{{route('task.add')}}">
                   <div class ="row">
                       <div class="col-md-6">
                           <label>Task Name</label>
                       </div>
                       <div class="col-md-6">
                           <input type="text" name="taskname" class="form-control" placeholder="Task Name" required><br>
                       </div>
                   </div>

                   <div class ="row">
                       <div class="col-md-6">
                           <label>Task Description</label>
                       </div>
                       <div class="col-md-6">
                           <input type="text" name="description" class="form-control" placeholder="Description" required><br>
                       </div>
                   </div>

                   <div class="row">
                       <div class="col-md-6">
                           <label>Task Assigner</label>
                       </div>
                       <div class ="col-md-6">
                           <div class="input-group" >
                               <select name="assigner" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>
                                   <option></option>
                                   @foreach($assigners as $assigner)
                                   <option value="{{$assigner->name}}">{{$assigner->name}}</option>
                                   @endforeach   
                               </select>
                           </div>
                       </div>
                   </div><br>

                   <div class="row">
                       <div class="col-md-6">
                           <label>Task Developer</label>
                       </div>
                       <div class ="col-md-6">
                           <div class="input-group" >
                               <select name="developer" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>
                                   <option></option>
                                   @foreach($developers as $developer)
                                   <option value="{{$developer->name}}">{{$developer->name}}</option>
                                   @endforeach   
                               </select>
                           </div>             
                       </div>
                   </div><br>

                   <input type="hidden" name="_token" value="{{csrf_token() }}">

                   <div class="row">
                       <div class="col-md-3"></div>
                       <div class="col-md-6">
                           <button type="submit" style="width: 300px" class="btn btn-success" class="form-control" >Submit</button>
                       </div>
                   </div>
               </form>
           </div>
        </div>
</body>
@endsection