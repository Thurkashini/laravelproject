<!--@extends('master')-->
@extends('layouts.mainlayout')

@section('content')
<body style="background-color: lightblue">

<section class="jumbotron text-center">
     <div class="container">
         <h1 class="jumbotron-heading">Task Management System</h1><br>
        @foreach($users as $user)
        <h2><strong>Hi {{$user->name }}</strong></h2><br>
       
        
        <table class='table' style="width:50%; margin-left: 280px">
           
            <tr>
                
                <td><span style="width:150px; align-content:"><a href="{{route('user.userhome')}}" class="btn btn-primary">Task Details</a></span></td>
                
                <td><span style="width:150px; align-content:"><a href="{{route('user.view')}}" class="btn btn-primary">Your Details</a></span></td>
                
                <td><span style="width:150px; align-content:"><a href="{{route('user.form',$user->id)}}" class="btn btn-primary">Edit Details</a></span></td>   
                
            </tr>
        </table>
         @endforeach
  
        <input type="hidden" name="_token" value="{{csrf_token() }}">

     </div>
     <img src="task4.jpg" width="1000" height="500">
</section>
   
</body>
@endsection
