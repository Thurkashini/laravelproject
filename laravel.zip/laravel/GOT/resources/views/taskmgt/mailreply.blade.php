<!--@extends('master')-->


@section('content')

<body style="background-color: lightskyblue">

    <br>
    <br>
        
    
<section class="jumbotron text-center">
     <div class="container">
       <h1 class="jumbotron-heading">Task Management System</h1>
              
            
              <p>Successfully complete the task by user </p>
              
              
     </div>
</section>

</body>
@endsection
