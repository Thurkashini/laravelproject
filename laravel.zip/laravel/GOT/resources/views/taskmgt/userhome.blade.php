<!--@extends('master')-->
@extends('layouts.mainlayout')
@section('content')

<body style="background-color: lightblue">

    <table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 100px; float: left; text-align:center"><button onclick="location.href='{{route('user.usermainhome')}}'" class="btn btn-primary"><<</button></span></td>
        </tr> 
    </table>
    <div class="col-xs-6" style="background-color: white;width: 900px; margin-left: 180px"><br>
        
        <h1 align='center'> <strong>Task Details </strong></h1><br><br>
        
        <h2 style="margin-left: 140px">Pending Tasks</h2><br>
    <table style="width:70%" class='table' align='center'>
    <tr>
        <td><strong>Task</strong></td>
        <td><strong>Task Description</strong></td>
        <td><strong>Task Assigner</strong></td>
        <td><strong>Task Developer</strong></td>
        <td><strong>Complete</strong></td>
    </tr>
    @foreach($ntasks as $ntask)
    <tr>
        <td>{{$ntask->taskname}}</td>
        <td>{{$ntask->description}}</td>
        <td>{{$ntask->assigner}}</td>
        <td>{{$ntask->developer}}</td> 
        <td><a href="{{route('sendmail',$ntask->id)}}">Complete</td>
    </tr>
    @endforeach
    </table>
     
    </div>
    

    <div class="col-xs-6" style="background-color: white; width: 900px; margin-left: 180px">
        <h2 style="margin-left: 140px">Completed Tasks</h2><br>
        <table style="width:70%" class='table' align='center'>
        <tr>
        <td><strong>Task</strong></td>
        <td><strong>Task Description</strong></td>
        <td><strong>Task Assigner</strong></td>
        <td><strong>Task Developer</strong></td>
        <td><strong>Complete</strong></td> 
        </tr>
    @foreach($ytasks as $ytask)
        <tr>
        <td>{{$ytask->taskname}}</td>
        <td>{{$ytask->description}}</td>
        <td>{{$ytask->assigner}}</td>
        <td>{{$ytask->developer}}</td> 
        <td>Complete</td>
        </tr>
    @endforeach
        </table>  
        <br>
    </div>
    <br>

       


</body>
@endsection