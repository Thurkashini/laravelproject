<!--@extends('master')-->
@extends('layouts.mainlayout')
@section('content')
<body style="background-color: lightblue">

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 10px; float: left; text-align:center"><button onclick="location.href='{{route('admin.home')}}'" class="btn btn-primary"><<</button></span></td>
            <td><span class="right" style="width: 10px; float: right; text-align:center"><button onclick="location.href='{{route('user.add')}}'" class="btn btn-primary">+</button></span></td>
        </tr>
</table>
    
         @if(\Session::has('success'))
        <div class="alert alert-success">
            <p>{{\Session::get ('success')}}</p>
        </div>
        @else
        
        @endif
        
    <div style="background-color: white; width:1000px;margin-left: 100px"><br>
        <h1 align='center'> USER DETAIL </h1><br>
            <table align='center' style="width:80%" class="table">
                <tr>
                    <td>Name</td>
                    <td>Email</td>
                    <td>Role</td>
                    <td>PhoneNo</td>
                    <td>Edit </td>
                    <td>Details</td>
                    <td>Delete</td>
                        
                </tr>
                @foreach($users as $user)
                <tr>
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>{{$user->role}}</td>
                    <td>{{$user->phoneno}}</td>
                    
                    <td><span class="right" style="width: 100px; text-align:center"><button onclick="location.href='{{route('oneuser',$user->id)}}'" class="btn btn-success">Details</button></span></td>
                    <td><span class="right" style="width: 100px; text-align:center"><button onclick="location.href='{{route('user.userupdate',$user->id)}}'" class="btn btn-success">Edit</button></span>
                    <td><span class="left" style="width: 100px; text-align:center"><button onclick="location.href='{{route('user.userdelete',$user->id)}}'" class="btn btn-success">Delete</button></span></td>
                    </td>
                </tr>
                @endforeach
            </table><br>
    </div>
<input type="hidden" name="_token" value="{{csrf_token() }}"> 
</body>   
@endsection