<!--@extends('master')-->
@extends('layouts.mainlayout')
@section('content')
<body style="background-color: lightskyblue">
<div class="row">
<h1 align='center'> USER DETAIL </h1>

</div>

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 100px; float: left; text-align:center"><button onclick="location.href='{{route('admin.home')}}'" class="btn btn-primary"><<</button></span></td>
            <td><span class="right" style="width: 100px; float: right; text-align:center"><button onclick="location.href='{{route('user.add')}}'" class="btn btn-primary">+</button></span></td>
        </tr>
        
</table>

<div class="row">
    <table style="width:80%" class='table' border ='3' align='center'>
        
    <tr>
        <th><strong>Name</strong></th>
        <th><strong>Email</strong></th>
        <th><strong>Gender</strong></th>
        <th><strong>Role</strong></th>
        <th><strong>Address</strong></th>
        <th><strong>Phone Number</strong></th>
        <th><strong>Status</strong></th>
        <th><strong>Edit</strong></th>
        <th><strong>Delete</strong></th>
    
    </tr>
    
    @foreach($users as $value)
    <tr>
        <td>{{$value->name}}</td>
        <td>{{$value->email}}</td>
        <td>{{$value->gender}}</td>
        <td>{{$value->role}}</td>
        <td>{{$value->address}}</td>
        <td>{{$value->phoneno}}</td>
        <td>{{$value->status}}</td>
        <td><a href="{{route('user.updateform',$value->id)}}">Edit</a></td>
        <td><a href="{{route('user.userdelete',$value->id)}}">Delete</a></td>
    </tr>
    @endforeach
</table>
</div>
</body>   
@endsection