<!--@extends('master')-->
@extends('layouts.mainlayout')

@section('content')
<body style="background-color: lightblue">
@foreach($users as $row)
<table style="width:100%" class='table' align='center'>
        <tr>
            <td style="width:20px"><button onclick="location.href='{{route('user.usermainhome')}}'" class="btn btn-primary"><<</button></td>
        </tr>
</table>

<input type="hidden" name="_token" value="{{csrf_token() }}">

            @if(count ($errors)>0)
                <ul>
                    @foreach($errors->all() as $error)
                    <li>
                         <div class="aler alert-danger">
                        {{ $error}}
                         </div>
                    </li>
                    @endforeach
                </ul> 
            @else
            
            @endif
            
            @if(\Session::has('success'))
            <div class="alert alert-success">
                <p>{{\Session::get ('success')}}</p>
            </div>
            @else
            
            @endif
            
            <div class="col-md-3"></div>
            <div class="jumbotron jumbotron-fluid" style="height: 680px; width: 800px; margin-left: 200px; background-color: white">
            
            <h2 align="center"><strong>Edit your details</strong></h2>
            <br> <br>
                <div class="col-md-6" style="align-content: center; padding-left: 70px">
                    <form method="POST" style="width: 550px" action="{{route('user.edit',$row->id)}}">
                        <input type="hidden" value="{{$row->id}}">
                        
                        <div class ="row">
                            <div class="col-md-6">
                                <label>Name</label>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control" placeholder="Name" value="{{$row->name}}"><br>
                            </div>
                        </div>
                        
                        <div class ="row">
                            <div class="col-md-6">
                                <label>Email</label>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="email" class="form-control" placeholder="Email" value="{{$row->email}}"><br>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <label>Password</label>
                            </div>
                            <div class="col-md-6">
                                <input type="password" name="password" class="form-control" placeholder="Password" value="{{$row->password}}"><br>
                                
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class ="col-md-6">
                                <label>Conform Password</label>
                            </div>
                            <div class ="col-md-6">
                                <input type="password" name="confrom_password" class="form-control" placeholder="Conform Password" value="{{$row->password}}"><br>
                                
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <label>Gender</label>
                            </div>
                            
                            <div class="col-md-3">
                                <input type="radio" name="gender" value="female" required>
                            
                                <label>Female</label>
                            </div>
                            
                            <div class="col-md-3">
                                <input type="radio" name="gender" value="male" required>
                            
                                <label>Male</label>
                            </div>
                           <br><br>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <label>Role</label>
                            </div>
                            <div class ="col-md-6">
                                <div class="input-group" >
                                    <select name="role" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>
                                        <option value="{{$row->role}}">{{$row->role}}</option>
                                        <option value="Admin">Admin</option>
                                        <option value="User">User</option>
                                    </select>
                                </div>
                            </div>
                        </div><br>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <label>Address</label>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="address" class="form-control" placeholder="Address" value="{{$row->address}}"><br>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <label>Phone Number</label>
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="phoneno" class="form-control" placeholder="Phone Number" value="{{$row->phoneno}}"><br>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <label>Status</label>
                            </div>
                            <div class ="col-md-6">
                                <div class="input-group" >
                                    <select name="status" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>                
                                            <option value="{{$row->status}}">{{$row->status}}</option>
                                            <option value="Active">Active</option>
                                            <option value="In-Active">In-active</option>
                                    </select>
                                </div>
                            </div>
                        </div><br>
                        
                        <input type="hidden" name="_token" value="{{csrf_token() }}">
                        
                        <div class="row">
                            <div class="col-md-3"></div>
                            <div class="col-md-6">
                                <button type="submit" style="width: 300px" class="btn btn-success" class="form-control">Edit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
</body>
@endforeach

@endsection