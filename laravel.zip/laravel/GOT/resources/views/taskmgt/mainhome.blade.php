<!--@extends('master')-->
@include('layouts.partials.homenav')
@section('content')

<body style="background-color: lightblue">
    <section class="jumbotron text-center">
        <div class="container">
            <h1 class="jumbotron-heading">Task Management System</h1>
            <p>This is task management system. Admin can assign the tasks between users.</p>
        </div>
    </section>
    
    <img src="task4.jpg" width="1150" height="500">
</body>
@endsection
