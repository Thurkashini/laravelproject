<!--@extends('master')-->
@extends('layouts.mainlayout')

@section('content')

<body style="background-color: lightblue">

  <table style="width:100%" class='table' align='center'>
        <tr>
            <td style="width:20px"><button onclick="location.href='{{route('user.userhome')}}'" class="btn btn-primary"><<</button></td>
        </tr>
</table>  
    
    
        
    
<section class="jumbotron text-center">
     <div class="container">
       <h1 class="jumbotron-heading">Task Management System</h1>
              
              <p>Successfully send the mail to task assigner</p>
              <p>Thank you for completing task!!</p>
     </div>
</section>
    
</body>
@endsection
