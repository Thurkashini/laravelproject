<!--@extends('master')-->
@extends('layouts.mainlayout')

@section('content')
<body style="background-color: lightblue">
<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 10px; float: left; text-align:center"><button onclick="location.href='{{route('user.usermainhome')}}'" class="btn btn-primary"><<</button></span></td>
            
        </tr>
</table>
<section class="jumbotron text-center">
     <div class="container">
         <h1 class="jumbotron-heading">Task Management System</h1><br>
        @foreach($users as $user)
        <h2><strong>Hi {{$user->name }}</strong></h2><br>
       
        
        <table class='table' style="width:35%; line-height:50px ; margin-left: 350px">
            <tr>
                <td><strong>Name</strong></td>
                <td>{{$user->name }}</td>
            </tr>
            <tr>
                <td><strong>Email</strong></td>
                <td>{{$user->email }}</td>
            </tr>
            <tr>
                <td><strong>Gender</strong></td>
                <td>{{$user->gender }}</td>
            </tr>
            <tr>
                <td><strong>Role</strong></td>
                <td>{{$user->role }}</td>
            </tr>
            <tr>
                <td><strong>Address</strong></td>
                <td>{{$user->address }}</td>
            </tr>
            <tr>
                <td><strong>Phone Number</strong></td>
                <td>{{$user->phoneno }}</td>
            </tr>
            <tr>
                <td><strong>Status</strong></td>
                <td>{{$user->status }}</td>
            </tr>
            
        </table>
         @endforeach
        
           
         
            
        
        <input type="hidden" name="_token" value="{{csrf_token() }}">

     </div>
</section>
</body>
@endsection
