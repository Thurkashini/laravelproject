<!--@extends('master')-->

@extends('layouts.loginlayout')

@section('content')
<body style="background-color: lightblue">
<div class ="row" style="padding-right:500px">
    <div class="col-md-5"></div>
    <div class="col-md-3">
 
        <br><br>
        

           @if ($message = Session::get('error'))
           <div class="row">
               <div class="alert alert-danger alert-block" style="width: 600px"> 
                    <strong>{{ $message }}</strong>
               </div>
           </div>
           @endif

       
        
        
       
                    <div class="content-wrapper"> 
                        <div class="row">
                            
                                <div class="jumbotron jumbotron-fluid" style="width: 600px; background-color: white">
                                    <h2 class="text-center">Login</h2>
                                
                                <form method="POST" action="{{route('login.action')}}" >
                                                            
                                    <input type="hidden" name="_token" value="{{csrf_token()}}">
                                    <div class ="form-group">
                                       
                                            <label>Email</label>
                                        
                                    </div>
                                    <div class="form-group">
                                       
                                            <input type="text" name="email" class="form-control" placeholder="Email"><br>
                                        
                                    </div>
                                    
                                    <div class ="form-group">
                                        
                                            <label>Password</label><br>
                                        
                                    </div>
                                    <div class="form-group">   
                                        
                                            <input type="password" name="password" placeholder="password" class="form-control"/><br>
                                        
                                    </div>

                                    <div class="form-group">   
                                       
                                        <button class="btn btn-lg btn-primary btn-block" type="submit">Log in</button>
                                       
                                    </div>

                                </form>
                                </div>
                            </div>
                        </div>
                              
                    
    </div>
                  
</div>    
@endsection