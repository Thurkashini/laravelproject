
 
<body>
    <!--reposive design-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
@include('layouts.partials.nav')
 
</body>
 
