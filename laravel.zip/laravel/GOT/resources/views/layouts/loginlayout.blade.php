

<body>
 
@include('layouts.partials.navlogin')
 
</body>