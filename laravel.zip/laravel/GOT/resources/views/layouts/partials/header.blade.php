<section class="jumbotron text-center">
     <div class="container">
       <h1 class="jumbotron-heading">Task Management System</h1>
              <p>
         <a href="#" class="btn btn-primary">Task Details</a>
         <a href="#" class="btn btn-secondary">User Details</a>
       </p>
     </div>
</section>