<?php

namespace App\Http\Controllers;
//use Illuminate\Support\Facades\Redirect;
//use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\User;
//use DB;
//use Illuminate\Routing\Redirector;
//use Illuminate\Support\Facades\DB;
//use Illuminate\Support\Facades\View;
//use Illuminate\Routing\Route;
use Auth;
use App\Http\Controllers\Hash;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function __construct()
    {
        $this->middleware('auth');  
    }
    
    public function admin()
    {
        return view('taskmgt.adminhome');
    }
  
    public function index()
    {
       $users=User::all();
       return view('taskmgt.userdetail',compact('users'));
    }

    public function create()
    {  
        return view('taskmgt.user');
    }
    
    public function useradd(Request $request)
    
    {   
            $this->validate($request, [
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'phoneno' => 'required|max:10|regex:/(0)[0-9]{9}/',
            'confrom_password' => 'required|same:password',
            'gender'=>'required',
            'role'=>'required',
            'address'=>'required',
            'status'=>'required']);
        
        User::UpdateOrCreate([
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>\Hash::make($request->password),
            'gender'=>$request->gender,
            'role'=>$request->role,
            'address'=>$request->address,
            'phoneno'=>$request->phoneno,
            'status'=>$request->status
        ]);
         return \redirect()->back()->with('success','Data Added sucessfully');
    }

    
     public function show($id)
    {
        $users=User::find([$id]);
        return view('taskmgt.userupdate',compact('users'));
    }

    public function userupdate(Request $request,$id)
    {
       $this->validate($request, [
        'email' => 'required|email',
        'phoneno' => 'required|max:10|regex:/(0)[0-9]{9}/',
        
    ]);
       
        User::where('id',$id)
         ->update([       
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>$request->password,
            'gender'=>$request->gender,
            'role'=>$request->role,
            'address'=>$request->address,
            'phoneno'=>$request->phoneno,
            'status'=>$request->status
        ]);
            
    return \redirect()->back()->with('success','Data Updated sucessfully');
        
    }

    public function userdestroy($id)
    {
        User::where(['id'=>$id])
            ->delete();
            
        return \redirect()->back()->with('success','Data Deleted sucessfully');  
    }
    
    public function alluser(){
        //dd("A");
        $users=User::all();
        return view('taskmgt.alluser',compact('users'));
    }
    
    public function oneuser($id){
        $users=User::find([$id]);
        return view('taskmgt.oneuser',compact('users'));
    }
    
    public function oneusers($id){
        $users=User::find([$id]);
        return view('taskmgt.oneuser',compact('users'));
    }
    
    public function userform(){
        //dd("A");
        $id=Auth::id();
       
        $users=User::find([$id]);
      
        return view('taskmgt.useredit',compact('users'));
    }

    public function useredit(Request $request,$id){
        $this->validate($request,[
        'email' => 'required|email',
        'phoneno' => 'required|max:10|regex:/(0)[0-9]{9}/',
        
    ]);
       
        User::where('id',$id)
         ->update([       
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>$request->password,
            'gender'=>$request->gender,
            'role'=>$request->role,
            'address'=>$request->address,
            'phoneno'=>$request->phoneno,
            'status'=>$request->status
        ]);
            
    return \redirect()->back()->with('success','Data Updated sucessfully');
        
    }
}
