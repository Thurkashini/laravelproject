<?php

namespace App\Http\Controllers;
use App\Mail\taskcomplete;
use App\User;
//use DB;
use Illuminate\Http\Request;
use App\Task;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\Controller;
use Auth;

class UseruserController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');  
    }
    
    //user main home
    public function home(){
        $id = Auth::id();
        $users=User::where('id',$id)->get();
        return view('taskmgt.usermainhome',  compact('users'));
    }

   //user home 
    public function taskuser(){
        $id = Auth::id();
        $users=User::where('id',$id)->get();
        
        foreach ($users as $user){
            $developer=$user->name;
            $yes='Yes';
            $no='no';
             
        $ntasks=Task::where([['developer','=',$developer],['complete','=',$no]])->get();
        $ytasks=Task::where([['developer','=',$developer],['complete','=',$yes]])->get();
        
        
            return view('taskmgt.userhome',compact('ytasks','ntasks','id'));
        }
    }
    
   

        public function mail($id){
        $yes='yes';
        Task::where('id',$id)
              ->update([
                 'complete'=> $yes
            ]);
        
        
        $tasks=Task::where('id',$id)->get();
            foreach ($tasks as $task){
                $assigner=$task->assigner;
                $users=User::where('name',$assigner)->get();
                
            
            foreach ($users as $user){
                $id=$user->id;              
                $email=$user->email;
                
                $subject='Task';
                $message ='task completed';
                         
        Mail::to($email)->send(new taskcomplete($subject,$message));
        
         return view('taskmgt.sendmail',compact('id'));
        
             }
        }
    
    }
    
    public function mailreply(){
        
        return view('taskmgt.mailreply',  compact('tasks'));
           
    }

    public function userview(){
        $id=Auth::id();
        $users= User::find([$id]);
        return view('taskmgt.userview',  compact('users'));
        
    }
            
   
}
