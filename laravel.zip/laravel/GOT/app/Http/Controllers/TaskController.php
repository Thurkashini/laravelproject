<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Task;
use App\User;
//use App\Http\Middleware\checkuser;

class TaskController extends Controller
{
   /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
     public function __construct()
    {
        $this->middleware('auth');
    }
    
    
    public function index()
    {
        $tasks=Task::all();
        return view('taskmgt.taskdetail',compact('tasks'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $tasks=Task::find([$id]);
        $assigners=User::where('role','admin')->get();
        $developers=User::where('role','user')->get();
        return view('taskmgt.taskupdate',compact('tasks','assigners','developers'));
    }
    
     public function taskupdate(Request $request,$id)
            {
        Task::where('id',$id)
         ->update([       
            'taskname'=> $request->taskname,
            'description'=> $request->description,
            'assigner'=> $request->assigner,
            'developer'=> $request->developer
        ]);
            
    return \redirect()->route("task.detail")->with('success','Data Updated sucessfully');
       
    }

    public function create(){
        
        $assigners=User::where('role','admin')->get();
        $developers=User::where('role','user')->get();
        
       
        return view('taskmgt.task',  compact('assigners','developers'));
    }

        public function taskadd(Request $request)
            {
            $this->validate($request,[
                'taskname'=>'required',
                'description'=>'required',
                'assigner'=>'required',
                'developer'=>'required'
            ]);
            Task::firstOrCreate(
                ['id'=>  auth()->id()],[
            'taskname'=> $request->taskname,
            'description'=> $request->description,
            'assigner'=> $request->assigner,
            'developer'=> $request->developer
        ]);
         return \redirect()->back()->with('success','Data Added sucessfully');
    }
    
    public function taskdestroy($id)
    {
        Task::where(['id'=>$id])
            ->delete();
            
        return \redirect()->back()->with('success','Data Deleted sucessfully');  
    }
}
