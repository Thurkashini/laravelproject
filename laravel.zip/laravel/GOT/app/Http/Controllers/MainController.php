<?php

namespace App\Http\Controllers;
//use App\Http\Controllers\Hash;
use Illuminate\Http\Request;
use Auth;
//use App\User;
//use App\Http\Controllers\Redirect;
//use Illuminate\Validation\Validator;
//use DB;

    
class MainController extends Controller
{
   
    function mainhome()
    {
        return view('taskmgt.mainhome');
    }
    
    
    function createlogin()
    {
        return view('taskmgt.login');
    }
   
   
    public function logs(Request $request){
        
        
       $this->validate($request,[
            'email' =>'required|email',
            'password' =>'required|alphaNum|min:3'
        ]);
            $email=$request->get('email');
            $password=$request->get('password');
            
        if (Auth::attempt(['email'=>$email,'password'=>$password,'role'=>'User'])) {
            
            return redirect()->route('user.usermainhome');
        }
        elseif(Auth::attempt(['email'=>$email,'password'=>$password,'role'=>'Admin'])){
                
            return redirect()->intended('adminhome'); 
        
        }else{
             return redirect()->intended('login')->with('error','Please enter the correct username and password');
        }
  
}
                public function logout(Request $request){
                   $request->session()->flush();
                   return redirect('/login');
                }
}
