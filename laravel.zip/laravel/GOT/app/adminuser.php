<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adminuser extends Model

{
    
    protected $fillable = [
        'name', 'email', 'password', 'gender', 'role', 'address', 'phoneno', 'status'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    
    protected $table='users';

    
    protected $primarykey='id';
    protected $hidden = [
        'password', 'remember_token',
    ];
   


}
