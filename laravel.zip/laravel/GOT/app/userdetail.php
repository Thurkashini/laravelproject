<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userdetail extends Model
{
      protected $fillable = [
        'name', 'email', 'password', 'gender', 'role', 'address', 'phoneno', 'status'
    ]; 
      protected $table='users';
      
}
