<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//use App\Http\Middleware\checkuser;

Route::get('/', function () {
    return 'hello';
});

//Route::group(['middleware'=>'checkuser'],function(){
    Route::get('adminhome',['middleware' => 'auth','uses'=>'UserController@admin'])->name("admin.home");
//}
    //);
    
   // Route::get('/userhome/{id}',['middleware' => 'auth','uses'=>'UseruserController@mail'])->name('sendmail');
//Route::post('/userhome/{id}',['middleware' => 'auth','uses'=>'UseruserController@mail'])->name('sendmail');
    Route::get('userview',['middleware' => 'auth','uses'=>'UseruserController@userview'])->name('user.view');
    
     Route::get('/mailreply',['middleware' => 'auth','uses'=>'UseruserController@mailreply'])->name('mail.reply');
    
    Route::post('mailreply',['middleware' => 'auth','uses'=>'UseruserController@mailreply'])->name('mail.reply');
    Route::get('/sendmail/{id}',['middleware' => 'auth','uses'=>'UseruserController@mail'])->name('sendmail');
Route::post('/sendmail/{id}',['middleware' => 'auth','uses'=>'UseruserController@mail'])->name('sendmail');

Route::get('alluser',['middleware' => 'auth','uses'=>'UserController@alluser'])->name("alluser");
Route::post('alluser',['middleware' => 'auth','uses'=>'UserController@alluser'])->name("alluser");  
Route::get('/useredit/{id}',['middleware' => 'auth','uses'=>'UserController@userform'])->name('user.form');
Route::post('useredit/{id}',['middleware' => 'auth','uses'=>'UserController@useredit'])->name('user.edit');

Route::get('mainhome','MainController@mainhome')->name("main.home");

Route::get('login','MainController@createlogin')->name("login");
Route::post('login','MainController@logs')->name("login.action");

Route::get('user',['middleware' => 'auth','uses'=>'UserController@create'])->name("user.addform");
Route::post('user',['middleware' => 'auth','uses'=>'UserController@useradd'])->name("user.add");

Route::get('task',['middleware' => 'auth','uses'=>'TaskController@create'])->name("task.addform");
Route::post('task',['middleware' => 'auth','uses'=>'TaskController@taskadd'])->name("task.add");


Route::get('/taskupdate/{id}',['middleware' => 'auth','uses'=>'TaskController@show'])->name("task.updateform");
Route::get('/userupdate/{id}',['middleware' => 'auth','uses'=>'UserController@show'])->name("user.updateform");


Route::post('taskupdate/{id}',['middleware' => 'auth','uses'=>'TaskController@taskupdate'])->name('task.taskupdate');

Route::post('userupdate/{id}',['middleware' => 'auth','uses'=>'UserController@userupdate'])->name("user.userupdate");


Route::get('taskdetail',['middleware' => 'auth','uses'=>'TaskController@index'])->name("task.detail");
Route::get('userdetail',['middleware' => 'auth','uses'=>'UserController@index'])->name("user.detail");


Route::get('taskdetail/{id}',['middleware' => 'auth','uses'=>'TaskController@taskdestroy'])->name('task.taskdelete');
Route::get('userdetail/{id}',['middleware' => 'auth','uses'=>'userController@userdestroy'])->name('user.userdelete');


Route::get('/','MainController@logout')->name('logout');
Route::post('/mainhome','MainController@logout')->name('logout');

Route::get('userhome',['middleware' => 'auth','uses'=>'UseruserController@taskuser'])->name("user.userhome");
Route::post('userhome',['middleware' => 'auth','uses'=>'UseruserController@taskuser'])->name("user.userhome");


Route::get('/usermainhome',['middleware' => 'auth','uses'=>'UseruserController@home'])->name('user.usermainhome');
Route::post('/usermainhome',['middleware' => 'auth','uses'=>'UseruserController@home'])->name('user.usermainhome');


Route::get('oneuser/{id}',['middleware' => 'auth','uses'=>'UserController@oneuser'])->name("oneuser");
//Route::get('oneuser',['middleware' => 'auth','uses'=>'UserController@oneuser'])->name("oneusers");




Route::get("/",function()
{
    //$users= users.all();
    //return view::make("users")->with("allusers",$users);
});