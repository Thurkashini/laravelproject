<!---->


<?php $__env->startSection('content'); ?>

<body style="background-color: lightskyblue">

    <br>
    <br>
        
    
<section class="jumbotron text-center">
     <div class="container">
       <h1 class="jumbotron-heading">Task Management System</h1>
              
            
              <p>Successfully complete the task by user </p>
              
              
     </div>
</section>

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>