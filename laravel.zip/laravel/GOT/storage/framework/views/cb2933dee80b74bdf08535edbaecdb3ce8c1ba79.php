<!---->

<?php $__env->startSection('content'); ?>
<body class="bg-info" id="about">
<div class="row">
<h1 align='center'> USER DETAIL </h1>


</div>

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 100px; float: left; text-align:center"><button onclick="location.href='<?php echo e(route('admin.home')); ?>'" class="btn btn-primary">Back</button></span></td>
             <td><span class="right" style="width: 100px; float: right; text-align:center"><button onclick="location.href='<?php echo e(route('user.add')); ?>'" class="btn btn-primary">Add</button></span></td>
        </tr>
        
</table>

<div class="row">
    <table style="width:80%" class='table' border ='3' align='center'>
        
    <tr>
        <th><strong>Name</strong></th>
        <th><strong>Email</strong></th>
        <th><strong>Gender</strong></th>
        <th><strong>Role</strong></th>
        <th><strong>Address</strong></th>
        <th><strong>Phone Number</strong></th>
        <th><strong>Status</strong></th>
        <th><strong>Edit</strong></th>
        <th><strong>Delete</strong></th>
    
    </tr>
    
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($value->name); ?></td>
        <td><?php echo e($value->email); ?></td>
        <td><?php echo e($value->gender); ?></td>
        <td><?php echo e($value->role); ?></td>
        <td><?php echo e($value->address); ?></td>
        <td><?php echo e($value->phoneno); ?></td>
        <td><?php echo e($value->status); ?></td>
      <td><a href="<?php echo e(route('user.updateform',$value->id)); ?>">Edit</a></td>
      <td><a href="<?php echo e(route('user.userdelete',$value->id)); ?>">Delete</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</body>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>