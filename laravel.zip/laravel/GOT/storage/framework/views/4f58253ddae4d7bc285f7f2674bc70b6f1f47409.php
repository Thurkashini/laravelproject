<!---->


<?php $__env->startSection('content'); ?>

<body style="background-color: lightblue">

<h1 align='center'> TASK DETAIL </h1>

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 100px; float: left; text-align:center"><button onclick="location.href='<?php echo e(route('admin.home')); ?>'" class="btn btn-primary"><<</button></span></td>
            <td><span class="right" style="width: 100px; float: right; text-align:center"><button onclick="location.href='<?php echo e(route('task.add')); ?>'" class="btn btn-primary">+</button></span></td>
        </tr>
</table>

        <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e(\Session::get ('success')); ?></p>
        </div>
        <?php else: ?>
        
        <?php endif; ?>
        
<div class="row">
    <div style="background-color: white;width: 80%; margin-left: 120px"><br><br><br>
    <table style="width:80%" class='table' align='center'>
    <tr>
        <td><strong>Task Name</strong></td>
        <td><strong>Task Description</strong></td>
        <td><strong>Task Assigner</strong></td>
        <td><strong>Task Developer</strong></td>
        <td><strong>Edit</strong></td>
        <td><strong>Delete</strong></td>
    </tr>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($task->taskname); ?></td>
        <td><?php echo e($task->description); ?></td>
        <td><?php echo e($task->assigner); ?></td>
        <td><?php echo e($task->developer); ?></td>
        <td><span class="left" style="width: 60px; text-align:center"><button onclick="location.href='<?php echo e(route('task.updateform',$task->id)); ?>'" class="btn btn-success">Edit</button></span>
        </td>
        <td><span class="left" style="width: 80px; text-align:center"><button onclick="location.href='<?php echo e(route('task.taskdelete',$task->id)); ?>'" class="btn btn-success">Delete</button></span>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br>
    </div>
</div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>