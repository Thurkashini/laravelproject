<?php $__env->startSection('content'); ?>

<div class ="row">
    <div class="col-md-5"></div>
    <div class="col-md-3">
        <br />
        
        
            
        <form method="POST" action="url{{}}">
            <h3 align="center">Login</h3>
            <div class ="row">
                <div class="col-md-12">
                    <label>Email</label>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <input type="text" name="email" class="form-control" placeholder="Email"><br>
                </div>
            </div>
            <div class ="row">
                <div class="col-md-12">
                    <label>Password</label><br>
                </div>
            </div>
            <div class="row">   
                <div class="col-md-12">
                    <input type="password" name="email" placeholder="password" class="form-control"/><br>
                </div>
            </div>
            <div class="row">   
                <div class="col-md-6">
                    <input type="submit" class="btn btn-primary" name="login"/><br>
                </div>
            </div>
            
        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>