<!---->



<?php $__env->startSection('content'); ?>
<body style="background-color: lightblue">
<div class ="row" style="padding-right:500px">
    <div class="col-md-5"></div>
    <div class="col-md-3">
 
        <br><br>
        

           <?php if($message = Session::get('error')): ?>
           <div class="row">
               <div class="alert alert-danger alert-block" style="width: 600px"> 
                    <strong><?php echo e($message); ?></strong>
               </div>
           </div>
           <?php endif; ?>

       
        
        
       
                    <div class="content-wrapper"> 
                        <div class="row">
                            
                                <div class="jumbotron jumbotron-fluid" style="width: 600px; background-color: white">
                                    <h2 class="text-center">Login</h2>
                                
                                <form method="POST" action="<?php echo e(route('login.action')); ?>" >
                                                            
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <div class ="form-group">
                                       
                                            <label>Email</label>
                                        
                                    </div>
                                    <div class="form-group">
                                       
                                            <input type="text" name="email" class="form-control" placeholder="Email"><br>
                                        
                                    </div>
                                    
                                    <div class ="form-group">
                                        
                                            <label>Password</label><br>
                                        
                                    </div>
                                    <div class="form-group">   
                                        
                                            <input type="password" name="password" placeholder="password" class="form-control"/><br>
                                        
                                    </div>

                                    <div class="form-group">   
                                       
                                        <button class="btn btn-lg btn-primary btn-block" type="submit">Log in</button>
                                       
                                    </div>

                                </form>
                                </div>
                            </div>
                        </div>
                              
                    
    </div>
                  
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.loginlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>