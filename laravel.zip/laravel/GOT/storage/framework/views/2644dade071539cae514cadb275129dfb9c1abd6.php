<!---->


<?php $__env->startSection('content'); ?>
<body style="background-color: lightblue">
<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 10px; float: left; text-align:center"><button onclick="location.href='<?php echo e(route('user.usermainhome')); ?>'" class="btn btn-primary"><<</button></span></td>
            
        </tr>
</table>
<section class="jumbotron text-center">
     <div class="container">
         <h1 class="jumbotron-heading">Task Management System</h1><br>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><strong>Hi <?php echo e($user->name); ?></strong></h2><br>
       
        
        <table class='table' style="width:35%; line-height:50px ; margin-left: 350px">
            <tr>
                <td><strong>Name</strong></td>
                <td><?php echo e($user->name); ?></td>
            </tr>
            <tr>
                <td><strong>Email</strong></td>
                <td><?php echo e($user->email); ?></td>
            </tr>
            <tr>
                <td><strong>Gender</strong></td>
                <td><?php echo e($user->gender); ?></td>
            </tr>
            <tr>
                <td><strong>Role</strong></td>
                <td><?php echo e($user->role); ?></td>
            </tr>
            <tr>
                <td><strong>Address</strong></td>
                <td><?php echo e($user->address); ?></td>
            </tr>
            <tr>
                <td><strong>Phone Number</strong></td>
                <td><?php echo e($user->phoneno); ?></td>
            </tr>
            <tr>
                <td><strong>Status</strong></td>
                <td><?php echo e($user->status); ?></td>
            </tr>
            
        </table>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
           
         
            
        
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

     </div>
</section>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>