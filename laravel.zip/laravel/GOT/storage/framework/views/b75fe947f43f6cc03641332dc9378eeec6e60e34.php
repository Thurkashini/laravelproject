<!---->

<?php $__env->startSection('content'); ?> 
<body style="background-color: lightblue">

<table style="width:100%" class='table' align='center'>
        <tr>
            <td style="width:20px"><button onclick="location.href='<?php echo e(route('alluser')); ?>'" class="btn btn-primary"><<</button></td>
        </tr>
</table><br>

            <?php if(count ($errors)>0): ?>
            <div class="aler alert-danger"><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <li>
                        <?php echo e($error); ?>

                    </li>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </ul><br>
            </div>   
            <br>
            <?php else: ?>
            
            <?php endif; ?>
            
            
            <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(\Session::get ('success')); ?></p>
            </div>
            <?php else: ?>
            <?php endif; ?>
            
            <div class="col-md-3"></div>
            <div class="jumbotron jumbotron-fluid" style="height: 680px; width: 800px; margin-left: 200px; background-color: white">
            
                <font color="black">
                <h2 class="text-center"><strong>Create New User</strong></h2>
                <br><br>
                    <div class="col-md-6" style="align-content: center; padding-left: 70px">

                        <form method="POST" style="width: 550px" action="<?php echo e(route('user.add')); ?>">

                            <div class ="row">
                                <div class ="col-md-6">
                                    <label>Name</label>
                                </div>
                                <div class ="col-md-6">
                                    <input type="text" name="name" class="form-control" placeholder="Name" required><br>
                                </div>
                            </div>
                            
                            <div class ="row">
                                <div class ="col-md-6">
                                    <label>Email</label>
                                </div>
                                <div class ="col-md-6">
                                    <input type="text" name="email" class="form-control" placeholder="Email" required><br>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class ="col-md-6">
                                    <label>Password</label>
                                </div>
                                <div class ="col-md-6">
                                    <input type="password" name="password" class="form-control" placeholder="Password" required><br>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class ="col-md-6">
                                    <label>Conform Password</label>
                                </div>
                                <div class ="col-md-6">
                                    <input type="password" name="confrom_password" class="form-control" placeholder="Conform Password" required><br>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class ="col-md-6">
                                    <label>Gender</label>
                                </div>
                                <div class ="col-md-3">
                                    <input type="radio" name="gender" value="female" required>

                                    <label>Female</label>
                                </div>

                                <div class ="col-md-3">
                                    <input type="radio" name="gender" value="male" required>

                                    <label>Male</label>
                                </div>
                               
                            </div><br>
                            
                            <div class="row">
                                <div class ="col-md-6">
                                    <label>Role</label>
                                </div>
                                <div class ="col-md-6">
                                    <div class="input-group" >
                                        <select name="role" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>
                                                <option></option>
                                                <option value="Admin">Admin</option>
                                                <option value="User">User</option>
                                        </select>
                                    </div>
                                </div>
                            </div><br>
                            
                            <div class="row">
                                <div class ="col-md-6">
                                    <label>Address</label>
                                </div>
                                <div class ="col-md-6">
                                    <input type="text" name="address" class="form-control" placeholder="Address" required><br>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class ="col-md-6">
                                    <label>Phone Number</label>
                                </div>
                                <div class ="col-md-6">
                                    <input type="text" name="phoneno" class="form-control" placeholder="Phone Number" required><br>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class ="col-md-6">
                                    <label>Status</label>
                                </div>
                                
                                <div class ="col-md-6">
                                    <div class="input-group" >
                                        <select name="status" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>
                                            <option></option>
                                            <option value="Active">Active</option>
                                            <option value="In-Active">In-active</option>
                                        </select>
                                    </div>

                                </div>
                            </div><br>
                            
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class ="col-md-6">
                                    <button type="submit" style="width: 300px" class="btn btn-success" class="form-control"><strong>Submit</strong></button>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>        
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>