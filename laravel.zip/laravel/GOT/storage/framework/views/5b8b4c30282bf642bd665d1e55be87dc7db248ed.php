<?php $__env->startSection('content'); ?>
<div class="row">
<h1 align='center'> User Detail </h1>


</div>

<table style="width:100%" class='table' align='center'>
        <tr>
             <td><span class="right" style="width: 100px; float: right; text-align:center"><button onclick="location.href='<?php echo e(route('user.add')); ?>'">Add</button></span></td>
        </tr>
        
</table>

<div class="row">
    <table style="width:60%" class='table' border ='1' align='center'>
        
    <tr>
        <td>Name</td>
        <td>Email</td>
        <td>Gender</td>
        <td>Role</td>
        <td>Address</td>
        <td>Phone Number</td>
        <td>Status</td>
        <td>Edit</td>
        <td>Delete</td>
       
    </tr>
    
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($value->name); ?></td>
        <td><?php echo e($value->email); ?></td>
        <td><?php echo e($value->gender); ?></td>
        <td><?php echo e($value->role); ?></td>
        <td><?php echo e($value->address); ?></td>
        <td><?php echo e($value->phoneno); ?></td>
        <td><?php echo e($value->status); ?></td>
      <td><a href="<?php echo e(route('user.updateform',$value->id)); ?>">Edit</a></td>
      <td><a href="<?php echo e(route('user.userdelete',$value->id)); ?>">Delete</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
    
@end
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>