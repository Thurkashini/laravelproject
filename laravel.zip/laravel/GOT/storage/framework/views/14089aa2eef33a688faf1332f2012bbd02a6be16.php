<!---->

<?php $__env->startSection('content'); ?>
<body style="background-color: lightblue">

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 50px; float: left; text-align:center"><button onclick="location.href='<?php echo e(route('alluser')); ?>'" class="btn btn-primary"><<</button></span></td>   
        </tr>
</table>
    <div style="background-color: white;width:60%; margin-left: 200px"><br>
        
    <h1 align='center'> USER DETAIL </h1><br>
    
    <table align='center' style="width:70%" class="table">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><strong>Name</strong></td>
            <td><?php echo e($user->name); ?></td>
        </tr>
        <tr>
            <td><strong>Email</strong></td>
            <td><?php echo e($user->email); ?></td>
        </tr>
        <tr>
            <td><strong>Gender</strong></td>
            <td><?php echo e($user->gender); ?></td>
        </tr>
        <tr>
            <td><strong>Role</strong></td>
            <td><?php echo e($user->role); ?></td>
        </tr>
        <tr>
            <td><strong>Address</strong></td>
            <td><?php echo e($user->address); ?></td>
        </tr>
        <tr>
            <td><strong>Phone Number</strong></td>
            <td><?php echo e($user->phoneno); ?></td>
        </tr>
        <tr>
            <td><strong>Status</strong></td>
            <td><?php echo e($user->status); ?></td>
        </tr>
        
        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br>
    </div>

</body>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>