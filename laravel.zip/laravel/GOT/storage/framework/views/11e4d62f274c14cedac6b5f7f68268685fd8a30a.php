

<body>
 
<?php echo $__env->make('layouts.partials.navlogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
</body>