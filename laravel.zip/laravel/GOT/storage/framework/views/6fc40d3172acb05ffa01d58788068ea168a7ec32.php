<!---->


<?php $__env->startSection('content'); ?>
<body style="background-color: lightblue">

<section class="jumbotron text-center">
     <div class="container">
       <h1 class="jumbotron-heading">Task Management System</h1>
              <p>
         <a href="<?php echo e(route('alluser')); ?>" class="btn btn-primary">User Details</a>
         <a href="<?php echo e(route('task.detail')); ?>" class="btn btn-primary">Task Details</a>
       </p>
     </div>
</section>
<img src="task4.jpg" width="1150" height="500">
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>