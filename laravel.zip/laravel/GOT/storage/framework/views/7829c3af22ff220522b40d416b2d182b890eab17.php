<!---->

<?php $__env->startSection('content'); ?>
<body style="background-color: lightblue">

<table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 10px; float: left; text-align:center"><button onclick="location.href='<?php echo e(route('admin.home')); ?>'" class="btn btn-primary"><<</button></span></td>
            <td><span class="right" style="width: 10px; float: right; text-align:center"><button onclick="location.href='<?php echo e(route('user.add')); ?>'" class="btn btn-primary">+</button></span></td>
        </tr>
</table>
    
         <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e(\Session::get ('success')); ?></p>
        </div>
        <?php else: ?>
        
        <?php endif; ?>
        
    <div style="background-color: white; width:1000px;margin-left: 100px"><br>
        <h1 align='center'> USER DETAIL </h1><br>
            <table align='center' style="width:80%" class="table">
                <tr>
                    <td>Name</td>
                    <td>Email</td>
                    <td>Role</td>
                    <td>PhoneNo</td>
                    <td>Edit </td>
                    <td>Details</td>
                    <td>Delete</td>
                        
                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td><?php echo e($user->phoneno); ?></td>
                    <td><span class="left" style="width: 100px; text-align:center"><button onclick="location.href='<?php echo e(route('user.userdelete',$user->id)); ?>'" class="btn btn-success">Delete</button></span></td>
                    <td><span class="right" style="width: 100px; text-align:center"><button onclick="location.href='<?php echo e(route('oneuser',$user->id)); ?>'" class="btn btn-success">Details</button></span></td>
                    <td><span class="right" style="width: 100px; text-align:center"><button onclick="location.href='<?php echo e(route('user.userupdate',$user->id)); ?>'" class="btn btn-success">Edit</button></span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table><br>
    </div>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
</body>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>