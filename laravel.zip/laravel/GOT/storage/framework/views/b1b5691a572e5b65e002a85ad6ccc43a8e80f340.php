


    <div class="navbar navbar-inverse bg-inverse">
     <div class="container d-flex justify-content-betIen">
       <a href="#" class="navbar-brand">
           <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    
                    <li class="signup-btn"><a href="<?php echo e(route('logout')); ?>"><strong>Log Out</strong></a></li>
                   
                </ul>
           </div>
               
       </a>
       
     </div>
   </div>

