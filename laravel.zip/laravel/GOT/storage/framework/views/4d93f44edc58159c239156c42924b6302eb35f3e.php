
 
<body>
    <!--reposive design-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo $__env->make('layouts.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
</body>
 
