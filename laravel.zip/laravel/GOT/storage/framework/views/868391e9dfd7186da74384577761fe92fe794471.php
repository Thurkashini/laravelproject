<!---->

<?php $__env->startSection('content'); ?>

<body style="background-color: lightblue">

    <table style="width:100%" class='table' align='center'>
        <tr>
            <td><span class="right" style="width: 100px; float: left; text-align:center"><button onclick="location.href='<?php echo e(route('user.usermainhome')); ?>'" class="btn btn-primary"><<</button></span></td>
        </tr> 
    </table>
    <div class="col-xs-6" style="background-color: white;width: 900px; margin-left: 180px"><br>
        
        <h1 align='center'> <strong>Task Details </strong></h1><br><br>
        
        <h2 style="margin-left: 140px">Pending Tasks</h2><br>
    <table style="width:70%" class='table' align='center'>
    <tr>
        <td><strong>Task</strong></td>
        <td><strong>Task Description</strong></td>
        <td><strong>Task Assigner</strong></td>
        <td><strong>Task Developer</strong></td>
        <td><strong>Complete</strong></td>
    </tr>
    <?php $__currentLoopData = $ntasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ntask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($ntask->taskname); ?></td>
        <td><?php echo e($ntask->description); ?></td>
        <td><?php echo e($ntask->assigner); ?></td>
        <td><?php echo e($ntask->developer); ?></td> 
        <td><a href="<?php echo e(route('sendmail',$ntask->id)); ?>">Complete</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
     
    </div>
    

    <div class="col-xs-6" style="background-color: white; width: 900px; margin-left: 180px">
        <h2 style="margin-left: 140px">Completed Tasks</h2><br>
        <table style="width:70%" class='table' align='center'>
        <tr>
        <td><strong>Task</strong></td>
        <td><strong>Task Description</strong></td>
        <td><strong>Task Assigner</strong></td>
        <td><strong>Task Developer</strong></td>
        <td><strong>Complete</strong></td> 
        </tr>
    <?php $__currentLoopData = $ytasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ytask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($ytask->taskname); ?></td>
        <td><?php echo e($ytask->description); ?></td>
        <td><?php echo e($ytask->assigner); ?></td>
        <td><?php echo e($ytask->developer); ?></td> 
        <td>Complete</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>  
        <br>
    </div>
    <br>

       


</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>