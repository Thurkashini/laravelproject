
    <div class="navbar navbar-inverse bg-inverse">
     <div class="container d-flex justify-content-betIen">
       
           <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-left">
                    
                    <li><a href="<?php echo e(route('main.home')); ?>"><strong>Back</strong></a></li>
                   
                </ul>
           </div>
               
       
     </div>
   </div>
