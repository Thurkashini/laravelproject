<!---->

<?php $__env->startSection('content'); ?>

<body style="background-color: lightblue">
<table style="width:100%" class='table' align='center'>
        <tr>
            <td style="width:20px"><button onclick="location.href='<?php echo e(route('task.detail')); ?>'" class="btn btn-primary"><<</button></td>
        </tr>
</table>

        <?php if(count ($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors ->all (); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php echo e($error); ?>

                </li>
            </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        
        <?php endif; ?>
        
        <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e(\Session::get ('success')); ?></p>
        </div>
        <?php else: ?>
        
        <?php endif; ?>
      
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3"></div>
        <div class="jumbotron jumbotron-fluid" style="height: 430px; width: 800px; margin-left: 200px; background-color:white;">
        <br/>
            <h3 align="center"><strong>Update Task</strong></h3>
            <br />
            <div class="col-md-6" style="align-content: center; padding-left: 70px"> 

                <form method="POST" style="width: 550px" action="<?php echo e(route('task.taskupdate',$row->id)); ?>"> 

                    <input type="hidden" value="<?php echo e($row->id); ?>">

                    <div class="row">
                        <div class="col-md-6">
                            <label>Task Name</label>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="taskname" value='<?php echo e($row->taskname); ?>' class="form-control" placeholder="Task Name" ><br>
                        </div>

                    </div>

                    <div class ="row">
                        <div class="col-md-6">
                            <label>Task Description</label>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="description" value='<?php echo e($row->description); ?>' class="form-control" placeholder="Description"><br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <label>Task Assigner</label>
                        </div>
                       <div class ="col-md-6">
                            <div class="input-group" >
                                <select name="assigner" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>
                                    <option><?php echo e($row->assigner); ?></option>
                                    <?php $__currentLoopData = $assigners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($assigner->name); ?>"><?php echo e($assigner->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                </select>
                            </div>
                        </div>
                    </div><br>

                    <div class="row">
                        <div class="col-md-6">
                            <label>Task Developer</label>
                        </div>
                        <div class ="col-md-6">
                            <div class="input-group" >
                                <select name="developer" id="select" style="width: 255px; height: 30px" class="col-md-12" class="combobox" required>
                                    <option><?php echo e($row->developer); ?></option>
                                    <?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($developer->name); ?>"><?php echo e($developer->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                </select>
                            </div>
                        </div>
                    </div><br>

                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-6">
                            <button type="submit" style="width: 300px" class="btn btn-success" class="form-control">Update</button>
                        </div>
                    </div>
                </form> 
            </div>
        </div>
</body> 
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>