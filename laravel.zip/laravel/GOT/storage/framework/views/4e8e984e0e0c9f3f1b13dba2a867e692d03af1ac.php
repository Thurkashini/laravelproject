<!---->
<?php echo $__env->make('layouts.partials.homenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<body style="background-color: lightblue">
    <section class="jumbotron text-center">
        <div class="container">
            <h1 class="jumbotron-heading">Task Management System</h1>
            <p>This is task management system. Admin can assign the tasks between users.</p>
        </div>
    </section>
    
    <img src="task4.jpg" width="1150" height="500">
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>